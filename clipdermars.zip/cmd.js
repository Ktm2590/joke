var optionsDiv = document.getElementById("options");

document.getElementById("cmd").addEventListener("change", function() {
	var cmd = this.value;
	optionsDiv.innerHTML = "";

	if (cmd === "ls") {
		// Ajout de l'option -al
		var input = document.createElement("input");
		input.type = "checkbox";
		input.name = "options[]";
		input.value = "-al";
		var label = document.createElement("label");
		label.appendChild(input);
		label.appendChild(document.createTextNode("-al"));
		optionsDiv.appendChild(label);

		// Ajout de l'option ./
		var input = document.createElement("input");
		input.type = "text";
		input.name = "args[]";
		input.value = "./";
		var label = document.createElement("label");
		label.appendChild(document.createTextNode("Ajouter l'argument "));
		label.appendChild(input);
		optionsDiv.appendChild(label);
	} else if (cmd === "cp") {
		// Ajout d'un champ pour les fichiers à copier
		var input1 = document.createElement("input");
		input1.type = "text";
		input1.name = "args[]";
		var input2 = document.createElement("input");
		input2.type = "text";
		input2.name = "args[]";
		var label = document.createElement("label");
		label.appendChild(document.createTextNode("Fichiers à copier : "));
		label.appendChild(input1);
		label.appendChild(document.createTextNode(" "));
		label.appendChild(input2);
		optionsDiv.appendChild(label);
	} else if (cmd === "uname") {
		// Ajout de l'option -an
		var input = document.createElement("input");
		input.type = "checkbox";
		input.name = "options[]";
		input.value = "-an";
		var label = document.createElement("label");
		label.appendChild(input);
		label.appendChild(document.createTextNode("-an"));
		optionsDiv.appendChild(label);
	}
});
