<?php

if(isset($_GET['filename'])) {
  $filename = $_GET['filename'];
  
  // Vérifier que le fichier existe dans le dossier /tmp/
  if(file_exists('/tmp/' . $filename)) {
    // Afficher l'image
    header('Content-Type: image/jpeg');
    readfile('/tmp/' . $filename);
  } else {
    // Si le fichier n'existe pas, afficher un message d'erreur
    echo 'Erreur : fichier non trouvé.';
  }
} else {
  // Si aucun nom de fichier n'est spécifié, afficher un message d'erreur
  echo 'Erreur : nom de fichier manquant.';
}

?>
