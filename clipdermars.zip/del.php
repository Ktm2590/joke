<?php
$file = "assets/" . $_POST["filename"];

if (file_exists($file)) {
    unlink($file);
    echo "Le fichier " . $_POST["filename"] . " a été supprimé.";
} else {
    echo "Le fichier " . $_POST["filename"] . " n'existe pas.";
}
?>
