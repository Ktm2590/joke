<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Formulaire pour exécuter une commande</title>
	<style>
		body {
  background-color: black;
  color: white;
  font-family: sans-serif;
}

.container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
}

h1 {
  text-align: center;
  margin-bottom: 30px;
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 5px;
}

select {
  width: 100%;
  padding: 10px;
  border: none;
  border-radius: 5px;
  background-color: #333;
  color: white;
}

.btn {
  display: inline-block;
  padding: 10px 20px;
  background-color: #ff5252;
  border: none;
  border-radius: 5px;
  color: white;
  text-decoration: none;
  cursor: pointer;
}

.hidden {
  display: none;
}

.output-container {
  margin-top: 30px;
  padding: 20px;
  background-color: #333;
}

.output-container p {
  margin: 0;
}

.error {
  color: red;
}

		}
	</style>
</head>
<body>
	<h1>Formulaire pour exécuter une commande</h1>
	<form method="post">
		<label for="command">Commande :</label>
		<select id="command" name="command">
			<option value="ls">ls</option>
			<option value="cd">cd</option>
			<option value="mkdir">mkdir</option>
			<option value="rm">rm</option>
		</select>
		<label for="options">Options :</label>
		<select id="options" name="options[]" multiple>
			<option value="-a">-a</option>
			<option value="-l">-l</option>
			<option value="-h">-h</option>
			<option value="-R">-R</option>
		</select>
		<button type="submit">Exécuter la commande</button>
	</form>
	<?php
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$command = $_POST['command'];
			$options = implode(' ', $_POST['options']);
			$output = shell_exec("$command $options 2>&1");
			echo "<pre id=\"output\">$output</pre>";
		}
	?>
</body>
</html>
