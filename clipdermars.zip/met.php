<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Ma super page d'accueil</title>
	<link rel="stylesheet" type="text/css" href="weath.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			// Animation pour le titre
			$('.main-title').animate({fontSize: '4em'}, 1000);
			$('.main-title').animate({fontSize: '3em'}, 1000);
			$('.main-title').animate({fontSize: '2em'}, 1000);
			$('.main-title').animate({fontSize: '3em'}, 1000);

			// Animation pour les boutons
			$('.btn').hover(function() {
				$(this).css('background-color', 'green');
			}, function() {
				$(this).css('background-color', '');
			});

			// Animation pour la météo
			$('#weather-form').submit(function(event) {
				event.preventDefault();
				var city = $('#city-input').val();
				$.getJSON('https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + city, function(data) {
					if (data.length > 0) {
						var lat = data[0].lat;
						var lon = data[0].lon;
						$.getJSON('https://api.openweathermap.org/data/2.5/weather?lat=' + lat + '&lon=' + lon + '&appid=42ba669814993904a4d1b4af9af733bb', function(data) {
							$('#weather-info').html('<h2>Météo à ' + data.name + '</h2><p>' + data.weather[0].description + '</p><p>Température : ' + (data.main.temp - 273.15).toFixed(1) + ' °C</p><p>Humidité : ' + data.main.humidity + '%</p>');
						}).fail(function() {
							alert('Une erreur est survenue lors de la récupération des données météo.');
						});
					} else {
						alert('Impossible de trouver la ville spécifiée.');
					}
				}).fail(function() {
					alert('Une erreur est survenue lors de la récupération des données géographiques.');
				});
			});
		});
	</script>
</head>
<body>
	<header>
		<h1 class="main-title">Ma super page d'accueil</h1>
	</header>
	<main>
		<div id="buttons-container">
			<a href="signup.php" class="btn">S'inscrire</a>
			<a href="logcheck.php" class="btn">Se connecter</a>
			<a href="abonnes.php" class="btn">Voir les abonnés</a>
			<form id="weather-form">
				<input type="text" id="city-input" placeholder="Entrez une ville">
				<button type="submit" class="btn">Afficher la météo</button>
			</form>
		</div>
		<div id="weather-info"></div>
	</main>
</body>
</html>
