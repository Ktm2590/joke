import os

# Chemin d'accès du fichier HTML
chemin_fichier = input("Entrez le chemin d'accès du fichier HTML : ")

# Ouvre le fichier en mode lecture/écriture
with open(chemin_fichier, 'r+') as fichier:
    contenu = fichier.read()
    
    # Cherche la position de la dernière balise </body> dans le fichier
    position = contenu.rfind('</body>')
    
    # Si la balise est trouvée, ajoute le code anti-clic avant
    if position != -1:
        contenu = contenu[:position] + '<script type=\'text/javascript\'>\n//<![CDATA[\n// Anti Klik Kanan\nvar message="pas toucher ! T\'as pas le droit";function clickIE4(){if(2==event.button)return alert(message),!1}function clickNS4(e){if((document.layers||document.getElementById&&!document.all)&&(2==e.which||3==e.which))return alert(message),!1}document.layers?(document.captureEvents(Event.MOUSEDOWN),document.onmousedown=clickNS4):document.all&&!document.getElementById&&(document.onmousedown=clickIE4),document.oncontextmenu=new Function("alert(message);return false");\n//]]>\n</script>\n' + contenu[position:]
        
        # Retourne au début du fichier et écrit le contenu modifié
        fichier.seek(0)
        fichier.write(contenu)
        print("Le code anti-clic a été ajouté avec succès au fichier HTML !")
    else:
        print("Erreur : balise </body> non trouvée dans le fichier HTML.")
