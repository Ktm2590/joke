var select = document.getElementById("cmd");
var options = document.getElementById("options");

select.addEventListener("change", function() {
	var cmd = select.value;
	var args = "";

	switch (cmd) {
		case "ls":
			args = "-al ./";
			break;
		case "cp":
			args = "file.txt file2.txt";
			break;
		case "uname":
			args = "-an";
			break;
	}

	if (args !== "") {
		options.classList.remove("hidden");
		document.getElementById("args").value = args;
	} else {
		options.classList.add("hidden");
		document.getElementById("args").value = "";
	}
});
