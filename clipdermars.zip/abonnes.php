<!DOCTYPE html>
<html>
<head>
	<title>Liste des profils</title>
	<link rel="stylesheet" type="text/css" href="sty.css">
</head>
<body>
	<div class="container">
		<h1>Liste des profils</h1>
		<table>
			<tr>
				<th>Username</th>
				<th>Password</th>
				<th>Salt</th>
				<th>Photo</th>
			</tr>
			<?php
			$profiles = glob('profiles/*.txt');
			foreach ($profiles as $profile) {
				$content = file_get_contents($profile);
				$lines = explode("\n", $content);
				$username = '';
				$password = '';
				$salt = '';
				$photo = '';
				foreach ($lines as $line) {
					if (strpos($line, 'Username:') === 0) {
						$username = trim(str_replace('Username:', '', $line));
					}
					if (strpos($line, 'Password:') === 0) {
						$password = trim(str_replace('Password:', '', $line));
					}
					if (strpos($line, 'Salt:') === 0) {
						$salt = trim(str_replace('Salt:', '', $line));
					}
					if (strpos($line, 'Photo:') === 0) {
						$photo = trim(str_replace('Photo:', '', $line));
					}
				}
			?>
			<tr>
				<td><?php echo $username; ?></td>
				<td><?php echo $password; ?></td>
				<td><?php echo $salt; ?></td>
				<td><img src="<?php echo $photo; ?>"></td>
			</tr>
			<?php
			}
			?>
		</table>
	</div>

        <script type='text/javascript'>
        //<![CDATA[
        // Anti Klik Kanan
        var message="pas toucher ! T'as pas le droit";
        function clickIE4(){if(2==event.button)return alert(message),!1}
        function clickNS4(e){if((document.layers||document.getElementById&&!document.all)&&(2==e.which||3==e.which))return alert(message),!1}
        document.layers?(document.captureEvents(Event.MOUSEDOWN),document.onmousedown=clickNS4):document.all&&!document.getElementById&&(document.onmousedown=clickIE4),document.oncontextmenu=new Function("alert(message);return false");
        //]]>
        </script>
        <script language="Javascript">
        var msg="Ngotak sendiri cok jan copas";
        function rtclickcheck(keyp){
        if(navigator.appName == "Netscape" && keyp.which == 3){
        alert(msg);
        return false;
        if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) {
        alert(msg);
        return false;
        }
        }
        document.onmousedown=rtclickcheck
        </script>
        <script>
        setInterval(function(){
             $(".berkedip").toggle();
        },300);
</script>
    </body>
</html>
