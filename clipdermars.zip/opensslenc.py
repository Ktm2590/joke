import subprocess

def encrypt_file(filename):
    key_file = "key.bin"
    subprocess.run(["openssl", "rand", "-out", key_file, "32"])
    subprocess.run(["openssl", "enc", "-aes-256-cbc", "-in", filename, "-out", filename + ".enc", "-pass", "file:" + key_file])

def decrypt_file(filename):
    key_file = "key.bin"
    subprocess.run(["openssl", "enc", "-aes-256-cbc", "-d", "-in", filename, "-out", filename[:-4], "-pass", "file:" + key_file])

# Exemple d'utilisation
encrypt_file(input("fichier.html"))
decrypt_file("fichier.html.enc")
