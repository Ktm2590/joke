<?php
if (isset($_GET['file'])) {
  $file = $_GET['file'];
  $filepath = 'tmp/' . $file;

  // Vérification que le fichier existe et est accessible en lecture
  if (file_exists($filepath) && is_readable($filepath)) {
    // Envoi des entêtes HTTP pour indiquer qu'il s'agit d'un téléchargement de fichier
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename=' . basename($filepath));
    header('Content-Length: ' . filesize($filepath));
    header('Pragma: public');
    header('Cache-Control: public, must-revalidate, post-check=0, pre-check=0');
    header('Expires: 0');
    // Envoi du contenu du fichier
    readfile($filepath);
    exit;
  } else {
    // Le fichier n'existe pas ou n'est pas accessible en lecture
    echo "Le fichier demandé n'est pas disponible.";
  }
}
?>
