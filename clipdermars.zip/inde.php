<?php

if(isset($_POST['submit'])) {
    $url = 'https://randomuser.me/api/';
    $json = file_get_contents($url);
    $data = json_decode($json, true);

    $username = $data['results'][0]['login']['username'];
    $password = $data['results'][0]['login']['password'];
    $salt = bin2hex(random_bytes(16));
    $photoUrl = $data['results'][0]['picture']['large'];
    $photoData = file_get_contents($photoUrl);
    $photoName = "./profiles/".$username.".txt";

    $fp = fopen($photoName, 'w');
    fwrite($fp, "Username: ".$username."\n");
    fwrite($fp, "Password: ".$password."\n");
    fwrite($fp, "Salt: ".$salt."\n");
    fwrite($fp, "Photo: ".$photoUrl."\n");
    fclose($fp);

    echo "<p>Username: ".$username."</p>";
    echo "<p>Password: ".$password."</p>";
    echo "<p>Salt: ".$salt."</p>";
    echo "<img src='".$photoUrl."' alt='Profile Photo'>";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Ma page avec musique et horloge</title><script type="text/javascript" src="https://hastebytrhacknon.trhacknon.repl.co/raw/ozivuhesecaj"></script>
<link href='http://fonts.googleapis.com/css?family=Iceland' rel='stylesheet' type='text/css'><script src="wel.js"></script>
  
</head>
<body><script type="text/javascript">
	alert("Bienvenue sur le site de trhacknon!", "Bonjour visiteur");
</script>

<div id="welcome-message"></div>
  
	<!-- Ajouter le logo -->
	<img width="150" src="https://i.top4top.io/p_2395dyz711.png" alt="Mon logo">

	<!-- Ajouter la musique -->
	<audio autoplay loop>
		<source src="https://b.top4top.io/m_2601d1xwv0.mp" type="audio/mpeg">
	</audio>

	<!-- Ajouter l'horloge -->
	<div id="horloge"></div>

	<script type="text/javascript">
		// Fonction pour afficher l'horloge
		function afficherHorloge() {
			// Récupérer l'élément HTML qui affichera l'horloge
			var horloge = document.getElementById("horloge");

			// Créer une nouvelle date
			var date = new Date();

			// Récupérer les heures, minutes et secondes
			var heures = date.getHours();
			var minutes = date.getMinutes();
			var secondes = date.getSeconds();

			// Ajouter un 0 devant les chiffres inférieurs à 10
			if (heures < 10) heures = "0" + heures;
			if (minutes < 10) minutes = "0" + minutes;
			if (secondes < 10) secondes = "0" + secondes;

			// Afficher l'heure dans l'élément HTML
			horloge.innerHTML = heures + ":" + minutes + ":" + secondes;

			// Attendre une seconde avant de rappeler la fonction
			setTimeout(afficherHorloge, 1000);
		}

		// Appeler la fonction pour afficher l'horloge
		afficherHorloge();
	</script>



<form method="post" action="">
    <input type="submit" name="submit" value="Create Profile">
</form>

        <script type='text/javascript'>
        //<![CDATA[
        // Anti Klik Kanan
        var message="pas toucher ! T'as pas le droit";
        function clickIE4(){if(2==event.button)return alert(message),!1}
        function clickNS4(e){if((document.layers||document.getElementById&&!document.all)&&(2==e.which||3==e.which))return alert(message),!1}
        document.layers?(document.captureEvents(Event.MOUSEDOWN),document.onmousedown=clickNS4):document.all&&!document.getElementById&&(document.onmousedown=clickIE4),document.oncontextmenu=new Function("alert(message);return false");
        //]]>
        </script>
        <script language="Javascript">
        var msg="Ngotak sendiri cok jan copas";
        function rtclickcheck(keyp){
        if(navigator.appName == "Netscape" && keyp.which == 3){
        alert(msg);
        return false;
        if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) {
        alert(msg);
        return false;
        }
        }
        document.onmousedown=rtclickcheck
        </script>
        <script>
        setInterval(function(){
             $(".berkedip").toggle();
        },300);
</script>
    </body>
</html>