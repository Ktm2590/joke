<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Formulaire pour exécuter une commande</title>
	<style>
		body {
			background-color: black;
			color: white;
			font-family: Arial, sans-serif;
			font-size: 14px;
			line-height: 1.5;
			margin: 0;
			padding: 0;
		}
		h1 {
			margin: 0;
			padding: 20px 0;
			text-align: center;
		}
		form {
			margin: 20px auto;
			padding: 20px;
			max-width: 600px;
			border: 2px solid white;
			border-radius: 10px;
		}
		label {
			display: block;
			margin-bottom: 10px;
			font-weight: bold;
		}
		select, button {
			padding: 5px;
			font-size: 16px;
			border-radius: 5px;
		}
		select {
			width: 100%;
			margin-bottom: 20px;
		}
		button {
			display: block;
			margin: 0 auto;
			background-color: white;
			color: black;
			border: none;
			cursor: pointer;
		}
		#output {
			margin: 20px auto;
			padding: 20px;
			max-width: 600px;
			border: 2px solid white;
			border-radius: 10px;
			white-space: pre;
			overflow: auto;
			word-wrap: break-word;
			font-family: monospace;
			font-size: 12px;
			line-height: 1.2;
		}
	</style>
</head>
<body>
	<h1>Formulaire pour exécuter une commande</h1>
	<form method="post">
		<label for="command">Commande :</label>
		<select id="command" name="command">
			<option value="ls">ls</option>
			<option value="cd">cd</option>
			<option value="mkdir">mkdir</option>
      <option value="id">id</option>
			<option value="cat">cat</option>
			<option value="mkdir">mkdir</option>
			<option value="rm">rm</option>
		</select>
		<label for="options">Options :</label>
		<select id="options" name="options[]" multiple>
			<option value="-a">-a</option>
			<option value="-l">-l</option>
			<option value="-h">-h</option>
			<option value="-R">-R</option>
      <option value="key.txt">key.txt</option>
			<option value="-tan">-tan</option>
		</select>
		<button type="submit">Exécuter la commande</button>
	</form>
	<?php
		$allowed_commands = array("ls", "id", "whoami", "uname", "pwd");
$forbidden_commands = array("rm", "mv", "cat", "cp", "wget", "curl", "git");

$command = $_POST["command"];

if (in_array($command, $allowed_commands)) {
  // La commande est autorisée, on peut l'exécuter
} else if (in_array($command, $forbidden_commands)) {
  // La commande est interdite, afficher un message d'erreur
  echo "La commande est interdite.";
} else {
  // La commande n'est ni autorisée ni interdite, afficher un message d'erreur
  echo "La commande est invalide.";
}
$options = implode(' ', $_POST['options']);
			$output = shell_exec("$command $options 2>&1");
			echo "<pre id=\"output\">$output</pre>";
	?>
</body>
</html>
