<!DOCTYPE html>
<html>
<head>
	<title>Liste des profils</title>
	<link rel="stylesheet" type="text/css" href="sty.css">
</head>
<body>
	<div class="container">
		<h1>Liste des profils</h1>
		<table>
			<tr>
				<th>Username</th>
				<th>Password</th>
				<th>Salt</th>
				<th>Photo</th>
			</tr>
			<?php
			$profiles = glob('profiles/*.txt');
			foreach ($profiles as $profile) {
				$content = file_get_contents($profile);
				$lines = explode("\n", $content);
				$username = '';
				$password = '';
				$salt = '';
				$photo = '';
				foreach ($lines as $line) {
					if (strpos($line, 'Username:') === 0) {
						$username = trim(str_replace('Username:', '', $line));
					}
					if (strpos($line, 'Password:') === 0) {
						$password = trim(str_replace('Password:', '', $line));
					}
					if (strpos($line, 'Salt:') === 0) {
						$salt = trim(str_replace('Salt:', '', $line));
					}
					if (strpos($line, 'Photo:') === 0) {
						$photo = trim(str_replace('Photo:', '', $line));
					}
				}
			?>
			<tr>
				<td><?php echo $username; ?></td>
				<td><?php echo $password; ?></td>
				<td><?php echo $salt; ?></td>
				<td><img src="<?php echo $photo; ?>"></td>
			</tr>
			<?php
			}
			?>
		</table>
	</div>
</body>
</html>
