#!/bin/bash

# Nombre de profils à récupérer
read -p "Nombre de profils à récupérer : " nb_profiles

# Création du dossier principal
if [ ! -d "profilessss" ]; then
    mkdir "profilessss"
fi

for i in $(seq 1 $nb_profiles); do
    # Récupération du profil
    response=$(curl -s "https://randomuser.me/api/")
    gender=$(echo $response | grep -Po '(?<="gender":")[^"]*')
    title=$(echo $response | grep -Po '(?<="title":")[^"]*')
    first=$(echo $response | grep -Po '(?<="first":")[^"]*')
    last=$(echo $response | grep -Po '(?<="last":")[^"]*')
    street_number=$(echo $response | grep -Po '(?<="number":)[^,]*')
    street_name=$(echo $response | grep -Po '(?<="name":")[^"]*')
    city=$(echo $response | grep -Po '(?<="city":")[^"]*')
    state=$(echo $response | grep -Po '(?<="state":")[^"]*')
    country=$(echo $response | grep -Po '(?<="country":")[^"]*')
    postcode=$(echo $response | grep -Po '(?<="postcode":")[^"]*')
    email=$(echo $response | grep -Po '(?<="email":")[^"]*')
    username=$(echo $response | grep -Po '(?<="username":")[^"]*')
    password=$(echo $response | grep -Po '(?<="password":")[^"]*')
    uuid=$(echo $response | grep -Po '(?<="uuid":")[^"]*')
    salt=$(echo $response | grep -Po '(?<="salt":")[^"]*')
    md5=$(echo $response | grep -Po '(?<="md5":")[^"]*')
    sha1=$(echo $response | grep -Po '(?<="sha1":")[^"]*')
    sha256=$(echo $response | grep -Po '(?<="sha256":")[^"]*')
    dob_date=$(echo $response | grep -Po '(?<="date":"[^"]*T[^"]*)')
    dob_age=$(echo $response | grep -Po '(?<="age":)[^,]*')
    registered_date=$(echo $response | grep -Po '(?<="registered":"[^"]*T[^"]*)')
    registered_age=$(echo $response | grep -Po '(?<="age":)[^,]*')
    phone=$(echo $response | grep -Po '(?<="phone":")[^"]*')
    cell=$(echo $response | grep -Po '(?<="cell":")[^"]*')
    id_name=$(echo $response | grep -Po '(?<="name":")[^"]*' | head -1)
    id_value=$(echo $response | grep -Po '(?<="value":")[^"]*')


   


  # Téléchargement et enregistrement de la photo
  curl -s "$photo" > "$profile_folder/photo.jpg"
done
