<?php

if(isset($_POST['submit'])) {
    $url = 'https://randomuser.me/api/';
    $json = file_get_contents($url);
    $data = json_decode($json, true);

    $username = $data['results'][0]['login']['username'];
    $password = $data['results'][0]['login']['password'];
    $salt = bin2hex(random_bytes(16));
    $photoUrl = $data['results'][0]['picture']['large'];
    $photoData = file_get_contents($photoUrl);
    $photoName = "./profiles/".$username.".txt";

    $fp = fopen($photoName, 'w');
    fwrite($fp, "Username: ".$username."\n");
    fwrite($fp, "Password: ".$password."\n");
    fwrite($fp, "Salt: ".$salt."\n");
    fwrite($fp, "Photo: ".$photoUrl."\n");
    fclose($fp);

    echo "<p>Username: ".$username."</p>";
    echo "<p>Password: ".$password."</p>";
    echo "<p>Salt: ".$salt."</p>";
    echo "<img src='".$photoUrl."' alt='Profile Photo'>";
}
?>

<form method="post" action="">
    <input type="submit" name="submit" value="Create Profile">
</form>
