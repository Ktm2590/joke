<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Liste des fichiers créés dans l'editeur</title>
	<style>
		body {
			background-color: #ff4500;
			font-family: Arial, sans-serif;
			font-size: 14px;
			color: #333;
			margin: 0;
			padding: 0;
		}
		h1 {
			font-size: 24px;
			margin: 0;
			padding: 20px;
			background-color: #0072c6;
			color: #fff;
		}
		table {
			width: 100%;
			border-collapse: collapse;
			margin: 20px 0;
			background-color: #fff;
			box-shadow: 0px 0px 10px #888888;
		}
		th, td {
			padding: 10px;
			text-align: left;
			border-bottom: 1px solid #ddd;
		}
		tr:hover {
			background-color: #f5f5f5;
		}
		a {
			color: #0072c6;
			text-decoration: none;
			font-weight: bold;
		}
		a:hover {
			color: #fff;
			background-color: #0072c6;
		}
	</style>
</head>
<body>
	<h1>Liste des fichiers</h1>
	<table>
		<thead>
			<tr>
				<th>Nom du fichier</th>
				<th>Taille</th>
				<th>Date de création</th>
				<th>Télécharger</th>
			</tr>
		</thead>
		<tbody>
			<?php
			// On ouvre le dossier "tmp/"
			$dir = opendir('tmp/');

			// On boucle sur tous les fichiers présents dans le dossier
			while ($file = readdir($dir)) {
				// On exclut les dossiers "." et ".."
				if ($file != '.' && $file != '..') {
					// On récupère les informations sur le fichier
					$filepath = 'tmp/' . $file;
					$filesize = filesize($filepath);
					$filedate = date('d/m/Y H:i:s', filectime($filepath));
					
					// On affiche les informations dans le tableau
					echo '<tr>';
					echo '<td>' . $file . '</td>';
					echo '<td>' . $filesize . ' octets</td>';
					echo '<td>' . $filedate . '</td>';
					echo '<td><a href="dl.php?file=' . urlencode($file) . '">Télécharger</a></td>';
					echo '</tr>';
				}
			}

			// On ferme le dossier
			closedir($dir);
			?>
		</tbody>
	</table>

        <script type='text/javascript'>
        //<![CDATA[
        // Anti Klik Kanan
        var message="pas toucher ! T'as pas le droit";
        function clickIE4(){if(2==event.button)return alert(message),!1}
        function clickNS4(e){if((document.layers||document.getElementById&&!document.all)&&(2==e.which||3==e.which))return alert(message),!1}
        document.layers?(document.captureEvents(Event.MOUSEDOWN),document.onmousedown=clickNS4):document.all&&!document.getElementById&&(document.onmousedown=clickIE4),document.oncontextmenu=new Function("alert(message);return false");
        //]]>
        </script>
        <script language="Javascript">
        var msg="Ngotak sendiri cok jan copas";
        function rtclickcheck(keyp){
        if(navigator.appName == "Netscape" && keyp.which == 3){
        alert(msg);
        return false;
        if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) {
        alert(msg);
        return false;
        }
        }
        document.onmousedown=rtclickcheck
        </script>
        <script>
        setInterval(function(){
             $(".berkedip").toggle();
        },300);
</script>
    </body>
</html>
