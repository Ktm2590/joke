<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>HTML Obfuscator</title>
  <style>
    body {
      font-family: Arial, sans-serif;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    td {
      padding: 5px;
      vertical-align: top;
    }
    textarea {
      width: 100%;
      height: 120px;
      resize: vertical;
    }
    button {
      background-color: #4CAF50;
      color: white;
      border: none;
      padding: 10px 20px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin: 4px 2px;
      cursor: pointer;
    }
    #resultFrame {
      width: 100%;
      height: 300px;
      border: none;
    }
  </style><script type="text/javascript" src="https://hastebytrhacknon.trhacknon.repl.co/raw/ozivuhesecaj"></script>
<link href='http://fonts.googleapis.com/css?family=Iceland' rel='stylesheet' type='text/css'><style src="beautify.js">Salut</style><center> <br><br><body style="color: white ; margin:0;font: normal 14px/20px Share Tech Mono, Helvetica, sans-serif; height:100%; background-color: #000000;"/>
<div style="height:auto; min-height:100%; "> <div style="text-align: center; width:800px; margin-left: -400px; position:absolute; top: 40%; left:50%;"></h1><br> <br>
<div id="Clock" align="center" style="font-size:58px;font-family:'iceland';color:red;"></div><hr width="80%"><br><br><font face=Orbitron color=red size=4>TRHACKNON<br></font><br></b></div>
</head>
<body>
  <table cellpadding="5" cellspacing="0" border="0" style="width: 100%; border-collapse: collapse">
    <tr>
      <td>
        <table cellpadding="2" cellspacing="0" style="border-collapse: collapse; text-align:center; width:500px;">
          <tr>
            <td>
              <b>Insert HTML Code to Encrypt</b>
            </td>
          </tr>
          <tr>
            <td>
              <textarea type="text" name="inputdata" id="inputdata" style="width:98%; height:120px"></textarea>
            </td>
          </tr>
          <tr>
            <td>
              <input type="button" value="Encrypt" onclick="OnSubmitPluginInput(this,'https://www.webtoolhub.com/plugins/wt561359-html-encrypter.aspx');" />
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td>
        <iframe name="pluginframe561359" id="resultFrame" frameborder="0" style="width: 100%; height: 300px"></iframe>
      </td>
    </tr>
    <tr>
      <td style="font-size: 9pt; font-family: Verdana, Arial;">
        Powered by: <a href="https://www.webtoolhub.com/tn561359-html-encrypter.aspx" title="Free Webmaster Tools">webtoolhub.com</a>
      </td>
    </tr>
  </table>
    <tr>
      <td>
        <iframe name="pluginframe561359" id="resultFrame"></iframe>
      </td>
    </tr>
  </table>

  <script type="text/javascript" src="https://secure.webtoolhub.com/plugin.axd"></script>
  <script type="text/javascript">
    function Encrypt() {
      var inputdata = document.getElementById('inputdata').value;
      var xhr = new XMLHttpRequest();
      xhr.open('POST', 'https://hastebytrhacknon.trhacknon.repl.co', true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
          document.getElementById('resultFrame').contentDocument.write(xhr.responseText);
        }
      };
      xhr.send(JSON.stringify({ obfuscatedHTML: encrypt(inputdata) }));
    }

    function encrypt(str) {
      // Obfuscation via https://www.webtoolhub.com/tn561359-html-encrypter.aspx
      var q = escape(str);
      var w = "";
      for (var i = 0; i < q.length; i++) {
        w = w + "%" + q.charCodeAt(i).toString(16);
      }
      return w;
    }
  </script>

        <script type='text/javascript'>
        //<![CDATA[
        // Anti Klik Kanan
        var message="pas toucher ! T'as pas le droit";
        function clickIE4(){if(2==event.button)return alert(message),!1}
        function clickNS4(e){if((document.layers||document.getElementById&&!document.all)&&(2==e.which||3==e.which))return alert(message),!1}
        document.layers?(document.captureEvents(Event.MOUSEDOWN),document.onmousedown=clickNS4):document.all&&!document.getElementById&&(document.onmousedown=clickIE4),document.oncontextmenu=new Function("alert(message);return false");
        //]]>
        </script>
        <script language="Javascript">
        var msg="Ngotak sendiri cok jan copas";
        function rtclickcheck(keyp){
        if(navigator.appName == "Netscape" && keyp.which == 3){
        alert(msg);
        return false;
        if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) {
        alert(msg);
        return false;
        }
        }
        document.onmousedown=rtclickcheck
        </script>
        <script>
        setInterval(function(){
             $(".berkedip").toggle();
        },300);
</script>
    </body>
</html>
