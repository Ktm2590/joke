import requests

# lire le contenu du fichier HTML
with open(input('fichier.html'), 'r') as f:
    html = f.read()

# envoyer le code HTML à Obfuscator.io
response = requests.post('https://obfuscator.io/', data={'input': html})

# enregistrer le code obfusqué dans un fichier HTML
with open('fichier_obfusque.html', 'w') as f:
    f.write(response.text)
