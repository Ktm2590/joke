<!DOCTYPE html>
<html>
<head>
	<title>Ma super page</title>
	<link rel="stylesheet" href="style.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="script.js"></script>
</head>
<body>
	<div id="logo-container">
		<img id="logo" src="https://i.top4top.io/p_2395dyz711.png" alt="Logo">
	</div>
	<div id="clock-container">
		<div id="clock"></div>
	</div>
	<audio src="https://b.top4top.io/m_2601d1xwv0.mp3" autoplay loop></audio>
</body>
</html>

		<nav>
			<ul>
				<li><a href="signnn.php">S'inscrire</a></li>
				<li><a href="logcheck.php">Se connecter</a></li>
				<li><a href="abonnes.php">Abonnés</a></li>
				<li>
					<form id="weather-form">
						<label for="cityInput">Météo</label>
						<input type="text" id="city" placeholder="Entrez une ville">
						<button type="weatherBtn">Chercher</button>
					</form>
				</li>
			</ul>
		</nav>
		<main>
			<p>Bienvenue sur ma page d'accueil. Ici, vous pouvez vous inscrire, vous connecter ou voir les abonnés.</p>
			<p id="weatherResult"></p>
			<div id="clock"></div>
		<div id="weatherResult"></div>
	</main>

	<script type="text/javascript">
		// Récupération des éléments du DOM
		const cityInput = document.getElementById('city');
		const weatherBtn = document.getElementById('weatherBtn');
		const weatherResult = document.getElementById('weatherResult');

		// Ajout d'un gestionnaire d'événement sur le bouton Météo
		weatherBtn.addEventListener('click', function() {
			const city = cityInput.value;
			const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=42ba669814993904a4d1b4af9af733bb`;

			// Appel de l'API OpenWeatherMap
			fetch(url)
				.then(response => response.json())
				.then(data => {
					// Affichage des données de la réponse
					const coord = data.coord;
					const weather = data.weather[0];
					const main = data.main;
					const wind = data.wind;
					const sys = data.sys;
					const timezone = data.timezone;

					const resultHTML = `
						<p>Coordonnées : (${coord.lat}, ${coord.lon})</p>
						<p>Météo : ${weather.description}</p>
						<p>Température : ${main.temp} K</p>
						<p>Pression : ${main.pressure} hPa</p>
						<p>Humidité : ${main.humidity} %</p>
						<p>Vent : ${wind.speed} m/s, ${wind.deg}°</p>
						<p>Heure de lever du soleil : ${new Date(sys.sunrise * 1000 + timezone * 1000).toLocaleTimeString()}</p>
						<p>Heure de coucher du soleil : ${new Date(sys.sunset * 1000 + timezone * 1000).toLocaleTimeString()}</p>
					`;

					weatherResult.innerHTML = resultHTML;
				})
				.catch(error => {
					weatherResult.innerHTML = `<p>Erreur : ${error.message}</p>`;
				});
		});
	</script>

	<audio autoplay loop>
		<source src="https://b.top4top.io/m_2601d1xwv0.mp3" type="audio/mp3">
	</audio>
	<script src="weath.js"></script>
</body>
</html>
