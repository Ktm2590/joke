<?php

if(isset($_POST['file'])) {
    $file = $_POST['file'];
    $content = $_POST['content'];
    // Vérifier si le fichier existe et est accessible en écriture
    if(file_exists($file) && is_writable($file)) {
        file_put_contents($file, $content);
        echo "Le fichier a été modifié avec succès.";
    } else {
        echo "Impossible de modifier le fichier.";
    }
}
