import subprocess

# Chemin vers le fichier chiffré
encrypted_file = input("fichier.enc")

# Chemin vers le fichier de sortie déchiffré
decrypted_file = input("fichier_decrypted.html") 

# Chemin vers le fichier contenant la clé
key_file = input("key.bin") 

# Commande OpenSSL pour le déchiffrement
openssl_cmd = f"openssl enc -aes-256-cbc -d -in {encrypted_file} -out {decrypted_file} -pass file:{key_file}"

# Exécution de la commande
subprocess.run(openssl_cmd, shell=True)
