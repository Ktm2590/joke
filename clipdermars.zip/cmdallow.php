<?php
// Limiter les fichiers accessibles au dossier courant
chdir(__DIR__);
ini_set('open_basedir', __DIR__);
// Liste des commandes autorisées
$allowed_commands = array("uname", "pwd", "ls", "id", "whoami");
// Liste des commandes interdites
$forbidden_commands = array("rm", "mv", "cat", "cp", "wget", "curl", "git");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	// Récupération de la commande et des options
	$command = $_POST["command"];
	$options = $_POST["options"];

	// Vérification de la validité de la commande
	if (in_array($command, $allowed_commands)) {
		// Vérification de la validité des options
		if (!preg_match('/[^A-Za-z0-9\-\_]/', $options)) {
			// Exécution de la commande
			exec($command . " " . $options, $output);
			// Affichage du résultat
			echo "<div style='background-color: black; color: white; padding: 10px; border: 2px solid red;'>Hostname, host: " . gethostname() . ", " . gethostbyaddr($_SERVER['REMOTE_ADDR']) . "<br>";
			echo "Commande exécutée : " . $command . " " . $options . "<br>";
			echo "Résultat :<br>";
			foreach ($output as $line) {
				echo $line . "<br>";
			}
			echo "</div>";
		} else {
			echo "<div style='background-color: black; color: white; padding: 10px; border: 2px solid red;'>Les options ne doivent contenir que des lettres, des chiffres, des tirets et des underscores.</div>";
		}
	} else {
		echo "<div style='background-color: black; color: lime; padding: 28px; border: 4px solid red;'>Commande non autorisée par trhacknon!</div>";
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Command Selector By TRHACKNON</title>
	<style>
		body {
			background-color: black;
			color: yellow;
      font-family: sans-serif;
		}
    .btn {
  display: inline-block;
  padding: 10px 20px;
  background-color: #ff5252;
  border: none;
  border-radius: 5px;
  color: white;
  text-decoration: none;
  cursor: pointer;
  }
    label {
  display: block;
  margin-bottom: 5px;
}
		form {
			padding: 10px;
			border: 2px solid red;
			display: inline-block;
		}
		input[type="submit"] {
			background-color: red;
			color: black;
			border: none;
			padding: 10px;
			margin-top: 10px;
			cursor: pointer;
		}
	</style>
</head>
<body>
	<form method="post" action="">
		<label for="command">Commande :</label>
		<select id="command" name="command">
			<option value="ls">ls</option>
      <option value="cat">cat</option>
			<option value="cp">cp</option>
			<option value="uname">uname</option>
			<option value="ps">ps</option>
			<option value="netstat">netstat</option>
			<option value="grep">grep</option>
			<option value="find">find</option>
			<option value="tar">tar</option>
		</select>
		</select>
		<br>
		<label for="options">Options :</label>
		<input type="text" id="options" name="options">
		<br>
		<input type="submit" value="Exécuter">
	</form>
</body>
</html>



<form method="POST">
    <label for="command">Commande : </label>
    <input type="text" name="command" id="command">
    <input type="submit" value="Envoyer">
</form>
