<?php
session_start();

// Vérification de l'existence du dossier profiles
if (!file_exists('profiles')) {
    echo "Dossier 'profiles' introuvable";
    exit;
}

// Vérification de la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Vérification de l'existence du fichier de profil
    $filename = "profiles/{$username}.txt";
    if (!file_exists($filename)) {
        echo "Profil introuvable";
        exit;
    }

    // Lecture des informations du profil
    $content = file_get_contents($filename);
    $lines = explode("\n", $content);
    $user_password = '';
    $photo_url = '';
    foreach ($lines as $line) {
        $parts = explode(':', $line, 2);
        $key = trim($parts[0]);
        $value = trim($parts[1] ?? '');
        if ($key === 'Password') {
            $user_password = $value;
        }
        if ($key === 'Photo') {
            $photo_url = $value;
        }
    }

    // Vérification du mot de passe
    if ($user_password !== $password) {
        echo "Mot de passe incorrect";
        exit;
    }

    // Affichage de la photo de profil
    echo "<img src='{$photo_url}' alt='Photo de profil'>";

    // Envoi d'une notification Telegram
    $telegram_url = "https://api.telegram.org/bot5944023323:AAGm8Lk5b7CdlWG7RnpPKK6mlG6lIlgNDHc/sendMessage";
    $chat_id = "-1001563259195";
    $text = "connection du profil :  {$username}!";
    $params = http_build_query(array(
        'chat_id' => $chat_id,
        'text' => $text
    ));
    file_get_contents($telegram_url . '?' . $params);
}

?>

<form method="post">
    <label for="username">Nom d'utilisateur</label>
    <input type="text" id="username" name="username"><br>
    <label for="password">Mot de passe</label>
    <input type="password" id="password" name="password"><br>
    <button type="submit">Se connecter</button>
</form>
