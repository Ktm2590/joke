<?php
session_start();

// Vérification de l'existence du dossier profiles
if (!file_exists('profiles')) {
    echo "Dossier 'profiles' introuvable";
    exit;
}

// Vérification de la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Vérification de l'existence du fichier de profil
    $filename = "profiles/{$username}.txt";
    if (!file_exists($filename)) {
        echo "Profil introuvable";
        exit;
    }

    // Lecture des informations du profil
    $content = file_get_contents($filename);
    $lines = explode("\n", $content);
    $user_password = '';
    $photo_url = '';
    foreach ($lines as $line) {
        $parts = explode(':', $line, 2);
        $key = trim($parts[0]);
        $value = trim($parts[1] ?? '');
        if ($key === 'Password') {
            $user_password = $value;
        }
        if ($key === 'Photo') {
            $photo_url = $value;
        }
    }

    // Vérification du mot de passe
    if ($user_password !== $password) {
        echo "Mot de passe incorrect";
        exit;
    }

    // Affichage de la photo de profil
    echo "<img src='{$photo_url}' alt='Photo de profil'>";

    // Envoi d'une notification Telegram
    $telegram_url = "https://api.telegram.org/bot5944023323:AAGm8Lk5b7CdlWG7RnpPKK6mlG6lIlgNDHc/sendMessage";
    $chat_id = "-1001563259195";
    $text = "connection du profil :  {$username}!";
    $params = http_build_query(array(
        'chat_id' => $chat_id,
        'text' => $text
    ));
    file_get_contents($telegram_url . '?' . $params);
}

?>
	<link href="https://fonts.googleapis.com/css?family=Varela" rel="stylesheet" type="text/css">
	<style>
		body {
			margin: 0;
			padding: 0;
			background-color: #000;
			color: #fff;
			font-family: 'Varela', sans-serif;
		}

		.glitch {
			position: absolute;
			top: 20px;
			left: 20px;
			font-size: 150px;
			animation: glitch 2s infinite;
		}

		.glitch::before,
		.glitch::after {
			content: attr(data-text);
			position: absolute;
			top: 0;
			left: 0;
		}

		.glitch::before {
			left: 2px;
			text-shadow: -1px 0 red;
		}

		.glitch::after {
			left: -2px;
			text-shadow: 1px 0 blue;
		}

		@keyframes glitch {
			0% {
				transform: skew(0deg);
			}
			20% {
				transform: skew(-5deg);
			}
			40% {
				transform: skew(5deg);
			}
			60% {
				transform: skew(0deg);
			}
			80% {
				transform: skew(5deg);
			}
			100% {
				transform: skew(-5deg);
			}
		}

		.menu {
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			display: flex;
			flex-direction: row;
			justify-content: space-evenly;
			align-items: center;
			width: 100%;
			max-width: 800px;
			padding: 20px;
			box-sizing: border-box;
			background-color: rgba(0, 0, 0, 0.5);
			border: 2px solid white;
			border-radius: 10px;
		}
		.menu a {
			color: #fff;
			text-decoration: none;
			font-size: 30px;
			font-weight: bold;
			text-transform: uppercase;
			letter-spacing: 2px;
			padding: 10px;
			transition: all 0.3s ease;
		}

		.menu a:hover {
			background-color: white;
			color: #000;
			transform: scale(1.1);
		}
	</style>	<link rel="stylesheet" href="glitch.css"><link rel="stylesheet" href="closty.css"><script type="text/javascript" src="https://hastebytrhacknon.trhacknon.repl.co/raw/ozivuhesecaj"></script>
<link href='http://fonts.googleapis.com/css?family=Iceland' rel='stylesheet' type='text/css'>		<img id="logo" src="https://i.top4top.io/p_2395dyz711.png" alt="Logo">
	</div><div id="Clock" align="center" style="font-size:58px;font-family:'iceland';color:red;"></div><hr width="100%"><br><br><font face=Orbitron color=red size=12><center>TRHACKNON<br></center></font><br></b></div>
<form method="post">
    <label for="username">Nom d'utilisateur</label>
    <input type="text" id="username" name="username"><br>
    <label for="password">Mot de passe</label>
    <input type="password" id="password" name="password"><br>
    <button type="submit">Se connecter</button>
</form>

        <script type='text/javascript'>
        //<![CDATA[
        // Anti Klik Kanan
        var message="pas toucher ! T'as pas le droit";
        function clickIE4(){if(2==event.button)return alert(message),!1}
        function clickNS4(e){if((document.layers||document.getElementById&&!document.all)&&(2==e.which||3==e.which))return alert(message),!1}
        document.layers?(document.captureEvents(Event.MOUSEDOWN),document.onmousedown=clickNS4):document.all&&!document.getElementById&&(document.onmousedown=clickIE4),document.oncontextmenu=new Function("alert(message);return false");
        //]]>
        </script>
        <script language="Javascript">
        var msg="Ngotak sendiri cok jan copas";
        function rtclickcheck(keyp){
        if(navigator.appName == "Netscape" && keyp.which == 3){
        alert(msg);
        return false;
        if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) {
        alert(msg);
        return false;
        }
        }
        document.onmousedown=rtclickcheck
        </script>
        <script>
        setInterval(function(){
             $(".berkedip").toggle();
        },300);
</script>
    </body>