<?php
if(isset($_POST['ville'])) {
    $ville = $_POST['ville'];

    // Appel de l'API OpenWeatherMap pour récupérer les coordonnées de la ville
    $url = "https://api.openweathermap.org/data/2.5/weather?q=" . urlencode($ville) . "&appid=42ba669814993904a4d1b4af9af733bb";
    $response = file_get_contents($url);
    $data = json_decode($response, true);

    // Affichage des informations météo
    if(isset($data['coord'])) {
        $lon = $data['coord']['lon'];
        $lat = $data['coord']['lat'];
        $weather = $data['weather'][0]['main'];
        $description = $data['weather'][0]['description'];
        $temp = $data['main']['temp'] - 273.15;
        $temp_min = $data['main']['temp_min'] - 273.15;
        $temp_max = $data['main']['temp_max'] - 273.15;
        $pressure = $data['main']['pressure'];
        $humidity = $data['main']['humidity'];
        $wind_speed = $data['wind']['speed'];
        $wind_deg = $data['wind']['deg'];
        $country = $data['sys']['country'];
        $name = $data['name'];

        echo "Météo à " . $name . " (" . $country . ")<br>";
        echo "Conditions : " . $weather . " (" . $description . ")<br>";
        echo "Température : " . round($temp, 1) . "°C (min : " . round($temp_min, 1) . "°C, max : " . round($temp_max, 1) . "°C)<br>";
        echo "Pression : " . $pressure . " hPa<br>";
        echo "Humidité : " . $humidity . "%<br>";
        echo "Vent : " . $wind_speed . " m/s, " . $wind_deg . "°<br>";
    } else {
        echo "Ville non trouvée.";
    }
} else {
    echo "Veuillez entrer une ville.";
}
?>
