<!DOCTYPE html>
<html>
  <head>
    <title>Accueil</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="stl.css" />
  </head>
  <body>
    <h1>Bienvenue sur notre site</h1>
    <form id="form" method="post" action="">
      <div>
        <label for="action">Que souhaitez-vous faire ?</label>
        <select id="action" name="action">
          <option value="inscription">S'inscrire</option>
          <option value="connexion">Se connecter</option>
          <option value="abonnes">Voir les abonnés</option>
          <option value="meteo">Voir la météo</option>
        </select>
      </div>
      <div id="inscription">
        <h2>Inscription</h2>
        <label for="nom">Nom :</label>
        <input type="text" id="nom" name="nom" />
        <label for="email">Email :</label>
        <input type="email" id="email" name="email" />
        <input type="submit" value="S'inscrire" />
      </div>
      <div id="connexion">
        <h2>Connexion</h2>
        <label for="email">Email :</label>
        <input type="email" id="email" name="email" />
        <label for="mdp">Mot de passe :</label>
        <input type="password" id="mdp" name="mdp" />
        <input type="submit" value="Se connecter" />
      </div>
      <div id="abonnes">
        <h2>Abonnés</h2>
        <p>Liste des abonnés :</p>
        <ul>
          <li>Alice</li>
          <li>Bob</li>
          <li>Charlie</li>
        </ul>
      </div>
      <div id="meteo">
        <h2>Météo</h2>
        <label for="ville">Ville :</label>
        <input type="text" id="ville" name="ville" />
        <input type="button" value="Voir la météo" onclick="getMeteo()" />
        <div id="meteo-result"></div>
      </div>
    </form>
    <script>
      // Afficher/cacher les div en fonction de l'action choisie
      const select = document.querySelector('#action');
      const divs = document.querySelectorAll('#form > div');
      select.addEventListener('change', () => {
        divs.forEach((div) => {
          if (div.id === select.value) {
            div.style.display = 'block';
          } else {
            div.style.display = 'none';
          }
        });
      });
</script>