<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];

  $profiles_path = './profiles/';
  $profile_file = $profiles_path . $username . '.txt';

  if (file_exists($profile_file)) {
    $profile_data = file_get_contents($profile_file);
    $profile_data = explode(':', $profile_data);

    $salt = $profile_data[0];
    $hash = $profile_data[1];
    $photo_url = $profile_data[2];

    $hashed_password = hash('sha256', $salt . $password);

    if ($hashed_password == $hash) {
      echo "TRHACKNON Welcome back, " . $username . "!<br><br>";

      echo "<form method='post' action='screenshot.php'>";
      echo "<input type='text' name='url' placeholder='Enter URL to screenshot'>";
      echo "<input type='submit' value='Take Screenshot'>";
      echo "</form>";

      echo "<br><img src='" . $photo_url . "' alt='Profile Photo'>";
    } else {
      echo "Invalid username or password.<br>";
    }
  } else {
    echo "Invalid username or password.<br>";
  }
}

?>

<form method="post" action="log.php">
  <label>Username:</label>
  <input type="text" name="username"><br>

  <label>Password:</label>
  <input type="password" name="password"><br>

  <input type="submit" value="Login">
</form>
