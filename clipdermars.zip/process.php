<?php
// Vérifie si le nom est trhacknon ou correspond à un nom de profil valide
function isAllowed($name) {
    $allowedNames = ["trhacknon", "balgo"];
    $profilesPath = "profiles/";
    $profiles = array_map('basename', glob($profilesPath . '*.txt'));

    return in_array($name, $allowedNames) || in_array($name . ".txt", $profiles);
}

// Récupère le nom envoyé par le formulaire
$name = $_POST["name"];

// Vérifie si le nom est autorisé
if (isAllowed($name)) {
    // Affiche un message de bienvenue
    if ($name === "trhacknon") {
        echo "<h1 id='welcome'>Bienvenue, trhacknon !</h1>";
    } else {
        $profilePath = "profiles/" . $name . ".txt";
        $profileContent = file_get_contents($profilePath);
        echo "<h1 id='welcome'>Bienvenue, " . $profileContent . " !</h1>";
    }
    // Redirige vers la page cmdallow.php
    header("Location: cmdallowcss.php");
} else {
    // Redirige vers abonnes.php
    header("Location: abonnes.php");
}
?>
