<!DOCTYPE html>
<html>
<head>
	<title>Ma page</title>
</head>
<body>

	<h1>Bienvenue sur ma page</h1>

	<ul>
		<li><a href="signnn.php">S'inscrire</a></li>
		<li><a href="logcheck.php">Se connecter</a></li>
		<li><a href="abonnes.php">Liste des abonnés</a></li>
		<li>
			<form method="get" action="meteoloc.php">
				<label for="ville">Entrez une ville :</label>
				<input type="text" id="ville" name="ville">
				<button type="submit">Rechercher</button>
			</form>
		</li>
	</ul>

</body>
</html>
