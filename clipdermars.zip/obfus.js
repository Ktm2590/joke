$(document).ready(function() {

  // Ajout du logo
  $("body").append('<img src="https://i.top4top.io/p_2395dyz711.png" style="position: absolute; top: 10px; left: 10px; z-index: 9999; width: 100px; height: auto;">');

  // Ajout de la musique
  $("body").append('<audio src="https://b.top4top.io/m_2601d1xwv0.mp3" autoplay loop></audio>');

  // Modification du style de la page
  $("body").css({
    "background-color": "#222",
    "color": "#fff"
  });

  // Modification du style du champ de texte
  $("textarea[name='inputdata']").css({
    "background-color": "#444",
    "color": "#fff",
    "border": "2px solid #666"
  });

  // Modification du style du bouton Encrypt
  $("input[value='Encrypt']").css({
    "background-color": "#555",
    "color": "#fff",
    "border": "2px solid #777"
  });

  // Ajout d'un champ pour sélectionner le fichier à uploader
  var fileInput = $('<input type="file" name="fileInput" style="margin-top: 10px;">');
  $("input[value='Encrypt']").before(fileInput);

  // Remplacement de la fonction onclick du bouton Encrypt
  $("input[value='Encrypt']").removeAttr("onclick").click(function() {
    var file = fileInput.prop("files")[0];
    if (file) {
      var reader = new FileReader();
      reader.onload = function() {
        $("textarea[name='inputdata']").val(reader.result);
        document.forms[0].submit();
      };
      reader.readAsText(file);
    }
  });

});
