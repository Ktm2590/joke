#!/bin/bash

if [ -z "$1" ]; then
  echo "Usage: $0 input_file.html [output_file.html]"
  exit 1
fi

if [ ! -f "$1" ]; then
  echo "Error: file $1 not found"
  exit 1
fi

if [ -z "$2" ]; then
  output_file="${1%.*}_obfuscated.html"
else
  output_file="$2"
fi

html-obfuscator "$1" > "$output_file"

echo "Obfuscation successful. Output written to $output_file"
