<!DOCTYPE html>
<html>
<head>
	<title>Conversion HTML vers JSO</title>
	<link rel="stylesheet" type="text/css" href="jso.css">
</head>
<body>
	<h1>Conversion HTML vers JSO</h1>
	<form action="jsoo.php" method="POST" enctype="multipart/form-data">
		<label for="html-file">Uploader un fichier HTML :</label>
		<input type="file" id="html-file" name="html-file">
		<input type="submit" value="Convertir en JSO">
	</form>
	<div id="result"></div>
	<script src="jso.js"></script>
</body>
</html>
