const form = document.querySelector('form');
const result = document.querySelector('#result');

form.addEventListener('submit', function(event) {
    event.preventDefault();

    // On envoie la requête pour convertir le fichier HTML en JSO
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'jsoo.php');
    xhr.addEventListener('load', function() {
        // On envoie le JSO sur l'API
        const jso = JSON.parse(xhr.responseText).jso;
        const script = document.createElement('script');
        script.textContent = jso;
        document.head.appendChild(script);

        // On affiche le résultat
        result.textContent = 'Le fichier HTML a été converti en JSO et envoyé à votre API.';
    });
    xhr.send(new FormData(form));
});
