<!DOCTYPE html>
<html>
<head>
	<title>Formulaire de commandes</title>
	<style>
		body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
			background-color: #f5f5f5;
		}

		form {
			width: 400px;
			margin: 20px auto;
			padding: 20px;
			background-color: #fff;
			border: 1px solid #ccc;
			border-radius: 5px;
		}

		label {
			display: block;
			margin-bottom: 10px;
		}

		input[type="submit"] {
			display: block;
			margin-top: 20px;
			padding: 10px;
			background-color: #4CAF50;
			color: #fff;
			border: none;
			border-radius: 5px;
			cursor: pointer;
		}

		input[type="text"] {
			padding: 5px;
			border: 1px solid #ccc;
			border-radius: 5px;
			width: 100%;
			box-sizing: border-box;
			margin-bottom: 10px;
		}

		.command-options {
			margin-left: 20px;
			margin-bottom: 10px;
		}

		.command-options label {
			display: inline-block;
			margin-right: 10px;
		}

		.command-options input[type="checkbox"] {
			margin-right: 5px;
		}

		.command-options input[type="text"] {
			width: auto;
			margin-bottom: 0;
		}
	</style>
</head>
<body>
	<form action="consox.php" method="GET">
		<label for="cmd">Sélectionnez une commande:</label>
		<select id="cmd" name="cmd">
			<option value="ls">ls</option>
			<option value="cp">cp</option>
			<option value="uname">uname</option>
			<option value="ps">ps</option>
			<option value="netstat">netstat</option>
			<option value="grep">grep</option>
			<option value="find">find</option>
			<option value="tar">tar</option>
		</select>

		<div class="command-options">
			<label><input type="checkbox" name="ls-options[]" value="-a"> Afficher les fichiers cachés</label>
			<label><input type="checkbox" name="ls-options[]" value="-l"> Afficher les détails</label>
			<label><input type="checkbox" name="ls-options[]" value="-h"> Afficher les tailles de fichiers en format lisible</label>
			<input type="text" name="ls-path" placeholder="Chemin (optionnel)">
		</div>

		<div class="command-options">
			<input type="text" name="cp-files" placeholder="Fichiers à copier (séparés par des espaces)">
			<input type="text" name="cp-destination" placeholder="Destination">
		</div>

		<div class="command-options">
			<label><input type="checkbox" name="uname-options[]" value="-a"> Afficher toutes les informations</label>
			<label><input type="checkbox" name="uname-options[]" value="-n"> Afficher le nom de l'hôte</label>
			<label><input type="checkbox" name="uname-options[]" value="-n"> Afficher le nom de l'hôte</label>

		</div>

		<button type="submit">Valider</button>
	</form><?php
		$allowed_commands = array('id', 'uname -a', 'ls', 'whoami', 'hostname');
		$forbidden_commands = array('wget', 'curl', 'rm', 'cat', 'mv', 'cp', 'touch');

		if (isset($_GET['cmd']) && in_array($_GET['cmd'], $allowed_commands)) {
			$cmd = $_GET['cmd'];
			$output = shell_exec($cmd);
			echo "<pre>$output</pre>";
		} else if (isset($_GET['cmd']) && in_array($_GET['cmd'], $forbidden_commands)) {
			echo "<p>Command not allowed.</p>";
		}
	?>
</body>
</html>
