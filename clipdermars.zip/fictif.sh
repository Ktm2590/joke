#!/bin/bash

# Nombre de profils à récupérer
nb_profiles=10

# Création du dossier principal
if [ ! -d "profilessss" ]; then
  mkdir profilessss
fi

for ((i=1; i<=nb_profiles; i++)); do
  # Récupération du profil
  response=$(curl -s "https://randomuser.me/api/")
  gender=$(echo "$response" | grep -oP '"gender": "\K[^"]+')
  name_title=$(echo "$response" | grep -oP '"title": "\K[^"]+' | head -1)
  name_first=$(echo "$response" | grep -oP '"first": "\K[^"]+')
  name_last=$(echo "$response" | grep -oP '"last": "\K[^"]+')
  street_number=$(echo "$response" | grep -oP '"number": \K[^,]+' | head -1)
  street_name=$(echo "$response" | grep -oP '"name": "\K[^"]+' | head -1)
  city=$(echo "$response" | grep -oP '"city": "\K[^"]+')
  state=$(echo "$response" | grep -oP '"state": "\K[^"]+')
  country=$(echo "$response" | grep -oP '"country": "\K[^"]+')
  postcode=$(echo "$response" | grep -oP '"postcode": "\K[^"]+')
  email=$(echo "$response" | grep -oP '"email": "\K[^"]+')
  username=$(echo "$response" | grep -oP '"username": "\K[^"]+')
  password=$(echo "$response" | grep -oP '"password": "\K[^"]+')
  uuid=$(echo "$response" | grep -oP '"uuid": "\K[^"]+')
  dob_date=$(echo "$response" | grep -oP '"date": "\K[^"]+')
  dob_age=$(echo "$response" | grep -oP '"age": \K\d+')
  registered_date=$(echo "$response" | grep -oP '"date": "\K[^"]+' | tail -1)
  registered_age=$(echo "$response" | grep -oP '"age": \K\d+' | tail -1)
  phone=$(echo "$response" | grep -oP '"phone": "\K[^"]+')
  cell=$(echo "$response" | grep -oP '"cell": "\K[^"]+')
  id_name=$(echo "$response" | grep -oP '"name": "\K[^"]+' | tail -1)
  id_value=$(echo "$response" | grep -oP '"value": "\K[^"]+' | tail -1)
  photo=$(echo "$response" | grep -oP '"large": "\K[^"]+')

  # Création du dossier pour le profil
  profile_folder="profilessss/$i"
  if [ ! -d "$profile_folder" ]; then
    mkdir "$profile_folder"
  fi

  # Enregistrement des informations du profil dans des fichiers
  echo "$gender" > "$profile_folder/gender.txt"
  echo "$name_title $name_first $name_last" > "$profile_folder/name.txt"
  echo "$street_number $street_name" > "$profile_folder/street.txt"
  echo "$city" > "$profile_folder/city.txt"
  echo "$state" > "$profile_folder/state.txt"
  echo "$state" >> "$profile_folder/location.txt"
    echo "$country" >> "$profile_folder/location.txt"
    echo "$postcode" >> "$profile_folder/location.txt"
    echo "$email" > "$profile_folder/email.txt"
    echo "$username" > "$profile_folder/user.txt"
    echo "$password" > "$profile_folder/pass.txt"
    echo -e "$uuid\n$username\n$password\n" > "$profile_folder/login.txt"
    echo -e "$photo\n" > "$profile_folder/photo.txt"
    echo "$dob $age" > "$profile_folder/dob.txt"
    echo "$registered" > "$profile_folder/registered.txt"
    echo "$phone" > "$profile_folder/phone.txt"
   


  # Téléchargement et enregistrement de la photo
  curl -s "$photo" > "$profile_folder/photo.jpg"
done
