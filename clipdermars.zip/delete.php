<?php

if(isset($_POST['file'])) {
    $file = $_POST['file'];
    // Vérifier si le fichier existe et est accessible en écriture
    if(file_exists($file) && is_writable($file)) {
        unlink($file);
        echo "Le fichier a été supprimé avec succès.";
    } else {
        echo "Impossible de supprimer le fichier.";
    }
}
