import requests
import os

# Nombre de profils à récupérer
nb_profiles = 10

# Création du dossier principal
if not os.path.exists("profiles"):
    os.makedirs("profiles")

for i in range(1, nb_profiles+1):
    # Récupération du profil
    response = requests.get("https://randomuser.me/api/")
    data = response.json()["results"][0]

    # Création du dossier pour le profil
    profile_folder = f"profiles/{i}"
    if not os.path.exists(profile_folder):
        os.makedirs(profile_folder)

    # Enregistrement des informations du profil dans des fichiers
    with open(f"{profile_folder}/gender.txt", "w") as f:
        f.write(data["gender"])

    with open(f"{profile_folder}/name.txt", "w") as f:
        f.write(f"{data['name']['title']} {data['name']['first']} {data['name']['last']}")

    with open(f"{profile_folder}/location.txt", "w") as f:
        f.write(f"{data['location']['street']['number']} {data['location']['street']['name']}\n")
        f.write(f"{data['location']['city']}\n")
        f.write(f"{data['location']['state']}\n")
        f.write(f"{data['location']['country']}\n")
        f.write(f"{data['location']['postcode']}\n")

    with open(f"{profile_folder}/email.txt", "w") as f:
        f.write(data["email"])

    with open(f"{profile_folder}/user.txt", "w") as f:
        f.write(f"{data['login']['username']}\n")
    
    with open(f"{profile_folder}/pass.txt", "w") as f:
        f.write(f"{data['login']['password']}\n")

    with open(f"{profile_folder}/login.txt", "w") as f:
        f.write(f"{data['login']['uuid']}\n")
        f.write(f"{data['login']['username']}\n")
        f.write(f"{data['login']['password']}\n")
        f.write(f"{data['login']['salt']}\n")
        f.write(f"{data['login']['md5']}\n")
        f.write(f"{data['login']['sha1']}\n")
        f.write(f"{data['login']['sha256']}\n")

    with open(f"{profile_folder}/dob.txt", "w") as f:
        f.write(data["dob"]["date"])
        f.write(str(data["dob"]["age"]))

    with open(f"{profile_folder}/registered.txt", "w") as f:
        f.write(data["registered"]["date"])
        f.write(str(data["registered"]["age"]))

    with open(f"{profile_folder}/phone.txt", "w") as f:
        f.write(data["phone"])

    with open(f"{profile_folder}/cell.txt", "w") as f:
        f.write(data["cell"])

    with open(f"{profile_folder}/id.txt", "w") as f:
        f.write(f"{data['id']['name']} {data['id']['value']}")

    # Téléchargement et enregistrement de la photo
    response = requests.get(data["picture"]["large"])
    with open(f"{profile_folder}/photo.jpg", "wb") as f:
        f.write(response.content)
    # Téléchargement et enregistrement de la photo
    response = requests.get(data["picture"]["medium"])
    with open(f"{profile_folder}/med.jpg", "wb") as f:
        f.write(response.content)
    # Téléchargement et enregistrement de la photo
    response = requests.get(data["picture"]["thumbnail"])
    with open(f"{profile_folder}/thumb.jpg", "wb") as f:
        f.write(response.content)
