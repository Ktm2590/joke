<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Page d'accueil</title>
	<link href="https://fonts.googleapis.com/css?family=Varela" rel="stylesheet" type="text/css">
	<style>
		body {
			margin: 0;
			padding: 0;
			background-color: #000;
			color: #fff;
			font-family: 'Varela', sans-serif;
		}

		.glitch {
			position: absolute;
			top: 20px;
			left: 20px;
			font-size: 150px;
			animation: glitch 2s infinite;
		}

		.glitch::before,
		.glitch::after {
			content: attr(data-text);
			position: absolute;
			top: 0;
			left: 0;
		}

		.glitch::before {
			left: 2px;
			text-shadow: -1px 0 red;
		}

		.glitch::after {
			left: -2px;
			text-shadow: 1px 0 blue;
		}

		@keyframes glitch {
			0% {
				transform: skew(0deg);
			}
			20% {
				transform: skew(-5deg);
			}
			40% {
				transform: skew(5deg);
			}
			60% {
				transform: skew(0deg);
			}
			80% {
				transform: skew(5deg);
			}
			100% {
				transform: skew(-5deg);
			}
		}

		.menu {
			position: absolute;
			top: 67%;
			left: 50%;
			transform: translate(-50%, -50%);
			display: flex;
			flex-direction: row;
			justify-content: space-evenly;
			align-items: center;
			width: 100%;
			max-width: 800px;
			padding: 20px;
			box-sizing: border-box;
			background-color: rgba(0, 0, 0, 0.5);
			border: 2px solid white;
			border-radius: 10px;
		}
		.menu a {
			color: #fff;
			text-decoration: none;
			font-size: 30px;
			font-weight: bold;
			text-transform: uppercase;
			letter-spacing: 2px;
			padding: 10px;
			transition: all 0.3s ease;
		}

		.menu a:hover {
			background-color: white;
			color: #000;
			transform: scale(1.1);
		}
    		.menu2 {
			position: absolute;
			top: 64%;
			left: 50%;
			transform: translate(-50%, -50%);
			display: flex;
			flex-direction: row;
			justify-content: space-evenly;
			align-items: center;
			width: 100%;
			max-width: 600px;
			padding: 20px;
			box-sizing: border-box;
			background-color: rgba(0, 0, 0, 0.5);
			border: 2px solid white;
			border-radius: 10px;
		}
		.menu2 a {
			color: #fff;
			text-decoration: none;
			font-size: 30px;
			font-weight: bold;
			text-transform: uppercase;
			letter-spacing: 2px;
			padding: 10px;
			transition: all 0.3s ease;
		}

		.menu2 a:hover {
			background-color: white;
			color: #000;
			transform: scale(1.1);
    }
		.menu1 {
			position: absolute;
			top: 77%;
			left: 50%;
			transform: translate(-50%, -50%);
			display: flex;
			flex-direction: row;
			justify-content: space-evenly;
			align-items: center;
			width: 100%;
			max-width: 800px;
			padding: 20px;
			box-sizing: border-box;
			background-color: rgba(0, 0, 0, 0.5);
			border: 2px solid white;
			border-radius: 10px;
    }
		.menu1 a {
			color: #fff;
			text-decoration: none;
			font-size: 30px;
			font-weight: bold;
			text-transform: uppercase;
			letter-spacing: 2px;
			padding: 10px;
			transition: all 0.3s ease;
		}

		.menu1 a:hover {
			background-color: white;
			color: #000;
			transform: scale(1.1);
		}
		.menu0 {
			position: absolute;
			top: 85%;
			left: 50%;
			transform: translate(-50%, -50%);
			display: flex;
			flex-direction: row;
			justify-content: space-evenly;
			align-items: center;
			width: 100%;
			max-width: 800px;
			padding: 20px;
			box-sizing: border-box;
			background-color: rgba(0, 0, 0, 0.5);
			border: 2px solid white;
			border-radius: 10px;
    }
		.menu0 a {
			color: #fff;
			text-decoration: none;
			font-size: 30px;
			font-weight: bold;
			text-transform: uppercase;
			letter-spacing: 2px;
			padding: 10px;
			transition: all 0.3s ease;
		}

		.menu0 a:hover {
			background-color: white;
			color: #000;
			transform: scale(1.1);
		}
	</style>	<link rel="stylesheet" href="glitch.css"><link rel="stylesheet" href="closty.css"><script type="text/javascript" src="https://hastebytrhacknon.trhacknon.repl.co/raw/ozivuhesecaj"></script>
<link href='http://fonts.googleapis.com/css?family=Iceland' rel='stylesheet' type='text/css'><script src="beautify.js"></script>	<script type="text/javascript">
  

// Modification de la fonction alert
window.alert = function(message) {
  // Création de la div
  var div = document.createElement("div");
  div.setAttribute("class", "alert-box");
  
  // Création de l'image de fermeture
  var closeIcon = document.createElement("img");
  closeIcon.setAttribute("src", "https://i.top4top.io/p_2395dyz711.png");
  closeIcon.setAttribute("alt", "close");
  closeIcon.setAttribute("class", "close-icon");
  closeIcon.onclick = function() {
    div.parentNode.removeChild(div);
  };
  
  // Création du texte de bienvenue
  var welcomeText = document.createElement("h2");
  welcomeText.innerHTML = "Bienvenue sur mon site !";
  
  // Création du message de présentation
  var introText = document.createElement("p");
  introText.innerHTML = "Je suis tracknon anonymous red hat, et je suis heureux de vous accueillir sur mon site !";
  
  // Ajout des éléments à la div
  div.appendChild(closeIcon);
  div.appendChild(welcomeText);
  div.appendChild(introText);
  
  // Ajout de la div au corps de la page
  document.body.appendChild(div);
  
  // Animation de la div
  var opacity = 0;
  var interval = setInterval(function() {
    if (opacity >= 1) clearInterval(interval);
    div.style.opacity = opacity;
    div.style.filter = 'alpha(opacity=' + opacity * 100 + ")";
    opacity += 0.1;
  }, 50);
  
  // Style de la div
  div.style.position = "fixed";
  div.style.top = "50%";
  div.style.left = "50%";
  div.style.transform = "translate(-50%, -50%)";
  div.style.backgroundColor = "#ffffff";
  div.style.border = "2px solid #000000";
  div.style.padding = "20px";
  div.style.textAlign = "center";
  div.style.boxShadow = "0 4px 8px rgba(0, 0, 0, 0.3)";
  div.style.borderRadius = "10px";
  
  // Style de l'image de fermeture
  closeIcon.style.position = "absolute";
  closeIcon.style.top = "10px";
  closeIcon.style.right = "10px";
  closeIcon.style.cursor = "pointer";
  closeIcon.style.width = "30px";
  
  // Style du texte de bienvenue
  welcomeText.style.color = "#000000";
  welcomeText.style.fontSize = "2.5rem";
  welcomeText.style.margin = "0";
  welcomeText.style.padding = "0";
  welcomeText.style.fontWeight = "bold";
  
  // Style du message de présentation
  introText.style.color = "#555555";
  introText.style.fontSize = "1.5rem";
  introText.style.marginTop = "20px";
  introText.style.marginBottom = "0";
  introText.style.lineHeight = "1.6";
};

	</script>
</head>
<body><br><br><br><script type="text/javascript">
	alert("Bienvenue sur mon site!", "Bonjour visiteur");
</script>
	<div class="glitch" data-text="ANONYMOUS">ANONYMOUS</div>
	<script src="clock.js"></script>
  <script src="weath.js"></script>
<br><br><br>
	<div id="logo-container">
		<img id="logo" src="https://i.top4top.io/p_2395dyz711.png" alt="Logo">
	</div><div id="Clock" align="center" style="font-size:58px;font-family:'iceland';color:red;"></div><hr width="100%"><br><br><font face=Orbitron color=red size=12><center>TRHACKNON<br></center></font><br></b></div>
	<div class="menu">
		<a href="logcheck.php">Log Check</a>
		<a href="signnn.php">Sign In</a>
		<a href="inde.php">virtual profile</a>
    		<a href="weather.php">meteo</a>
		<a href="abonnes.php">Abonnés</a></div>
  <div class="menu2">
    		<a href="wc.php">éditeur html/js/css</a>
</div>
	<div class="menu0">
    		<a href="cons.php">terminal command</a>
      	<a href="cmdallow.php">terminal cmdallow</a>
    		<a href="consoblack.php">terminal consoblack</a></div>
	<div class="menu1">
    		<a href="cmdallowcsstmp.php">terminal perso</a>
    <a href="obfus.php">obfuscator php</a>
    		<a href="indexob.php">Encrypt html</a>
        		<a href="tg.php">telegram tool by trhacknon</a>
	</div>
        <script type='text/javascript'>
        //<![CDATA[
        // Anti Klik Kanan
        var message="pas toucher ! T'as pas le droit";
        function clickIE4(){if(2==event.button)return alert(message),!1}
        function clickNS4(e){if((document.layers||document.getElementById&&!document.all)&&(2==e.which||3==e.which))return alert(message),!1}
        document.layers?(document.captureEvents(Event.MOUSEDOWN),document.onmousedown=clickNS4):document.all&&!document.getElementById&&(document.onmousedown=clickIE4),document.oncontextmenu=new Function("alert(message);return false");
        //]]>
        </script>
        <script language="Javascript">
        var msg="Ngotak sendiri cok jan copas";
        function rtclickcheck(keyp){
        if(navigator.appName == "Netscape" && keyp.which == 3){
        alert(msg);
        return false;
        if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) {
        alert(msg);
        return false;
        }
        }
        document.onmousedown=rtclickcheck
        </script>
        <script>
        setInterval(function(){
             $(".berkedip").toggle();
        },300);
</script>
    </body>
</html>
