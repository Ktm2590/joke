<?php
$host = gethostname();
$user = get_current_user();
?>
<!DOCTYPE html>
<html>
  <head>
    <style>
      body {
  font-family: sans-serif;
  background-color: #f2f2f2;
}

#wrapper {
  max-width: 800px;
  margin: 0 auto;
  padding: 30px;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
  font-size: 2rem;
  margin-bottom: 30px;
  text-align: center;
}

label {
  display: block;
  margin-bottom: 10px;
}

select {
  width: 100%;
  margin-bottom: 20px;
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

button[type="submit"] {
  display: block;
  margin: 0 auto;
  padding: 5px 20px;
  background-color: #0077ff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease-in-out;

    </style>
    <meta charset="UTF-8">
    <title>Commandes autorisées</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div id="wrapper">
      <h1>Commandes autorisées</h1>
      <div id="system-info">
        <?php
          echo "<p>Host: " . $_SERVER['HTTP_HOST'] . "</p>";
          echo "<p>uname: " . gethostname() . "</p>";
          echo "<p>User: " . exec('uname -an') . "</p>";
          echo "<p>User: " . $user . "</p>";
        ?>
      </div>
      <form action="exect.php" method="POST">
        <label for="command">Commande :</label>
        <select name="command" id="command">
          <option value="ls profiles">ls profiles</option>
          <option value="id">id</option>
          <option value="uname -a">uname -a</option>
          <option value="ls">ls</option>
          <option value="whoami">whoami</option>
          <option value="cat /etc/passwd">cat /etc/passwd</option>
          <option value="pwd">pwd</option>
        </select>
        <button type="submit">Exécuter</button>
      </form>
      <div id="output"></div>
    </div>
    <script src="script.js"></script>
  </body>
</html>
