<?php

if(isset($_POST['submit'])) {
    $url = 'https://randomuser.me/api/';
    $json = file_get_contents($url);
    $data = json_decode($json, true);

    $username = $data['results'][0]['login']['username'];
    $password = $data['results'][0]['login']['password'];
    $salt = bin2hex(random_bytes(16));
    $photoUrl = $data['results'][0]['picture']['large'];
    $photoData = file_get_contents($photoUrl);
    $photoName = "./profiles/".$username.".txt";

    $fp = fopen($photoName, 'w');
    fwrite($fp, "Username: ".$username."\n");
    fwrite($fp, "Password: ".$password."\n");
    fwrite($fp, "Salt: ".$salt."\n");
    fwrite($fp, "Photo: ".$photoUrl."\n");
    fclose($fp);

    echo "<p>Username: ".$username."</p>";
    echo "<p>Password: ".$password."</p>";
    echo "<p>Salt: ".$salt."</p>";
    echo "<img src='".$photoUrl."' alt='Profile Photo'>";
}
?>
    <title>Ma page</title>
    <script src="musique.js"></script>
    <script>
       function showTime() {
 var a_p = "";
 var today = new Date();
 var curr_hour = today.getHours();
 var curr_minute = today.getMinutes();
 var curr_second = today.getSeconds();
 if (curr_hour < 12) {
 a_p = "AM";
 } else {
 a_p = "PM";
 }
 if (curr_hour == 0) {
 curr_hour = 12;
 }
 if (curr_hour > 12) {
 curr_hour = curr_hour - 12;
 }
 curr_hour = checkTime(curr_hour);
 curr_minute = checkTime(curr_minute);
 curr_second = checkTime(curr_second);
 document.getElementById('clock').innerHTML=curr_hour + ":" + curr_minute + ":" + curr_second + " " + a_p;
 }
 
 function checkTime(i) {
 if (i < 10) {
 i = "0" + i;
 }
 return i;
 }
 setInterval(showTime, 500);
 

 var months = ['Janvier', 'Fevrier', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Aout', 'Septembre', 'Octobre', 'Novembre', 'Decembre'];
 var myDays = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
 var date = new Date();
 var day = date.getDate();
 var month = date.getMonth();
 var thisDay = date.getDay(),
 thisDay = myDays[thisDay];
 var yy = date.getYear();
 var year = (yy < 1000) ? yy + 1900 : yy;
 document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);
 
    </script>

	<link rel="stylesheet" href="clock.css">
<script type="text/javascript" src="https://hastebytrhacknon.trhacknon.repl.co/raw/ozivuhesecaj"></script>
<link href='http://fonts.googleapis.com/css?family=Iceland' rel='stylesheet' type='text/css'>
  </head>
  <body style="color: white ; margin:0;font: normal 14px/20px Share Tech Mono, Helvetica, sans-serif; height:100%; background-color: #000000;"/>
<div style="height:auto; min-height:100%; "> <div style="text-align: center; width:800px; margin-left: -400px; position:absolute; top: 20%; left:50%;"></h1><br> <br>
<div id="Clock" align="center" style="font-size:58px;font-family:'iceland';color:red;"></div><hr width="80%"><br><br><font face=Orbitron color=red size=4>TRHACKNON RED HAT PLAYER<br></font><br></b></div>
    <audio autoplay loop>
      <source src="https://b.top4top.io/m_2601d1xwv0.mp3" type="audio/mpeg">
    </audio>
    <div id="clock"></div>


<form method="post" action="">
    <input type="submit" name="submit" value="Create Profile">
</form>
  </body>
</html>