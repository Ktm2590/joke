<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Page Preview</title>
    <style>
      #preview {
        width: 100%;
        height: auto;
      }
    </style>
  </head>
  <body>
    <h1>Page Preview</h1>
    <img id="preview" src="https://api.apiflash.com/v1/urltoimage?access_key=df5872bcc4c9412da027ee971c0cc046&amp;wait_until=page_loaded&amp;url=https://clipder.trhacknon.repl.co/jst.php" alt="Page Preview">
  </body>
</html>
