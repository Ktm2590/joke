<?php

if(isset($_GET['file'])) {
    // Vérifier si le fichier existe
    if(file_exists($_GET['file'])) {
        // Définit les entêtes HTTP pour forcer le téléchargement du fichier
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($_GET['file']).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($_GET['file']));
        readfile($_GET['file']);
        exit;
    }
}
