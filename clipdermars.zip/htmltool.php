<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>HTML Obfuscator</title>
  <style>
    /* Ajouter vos styles CSS ici */
  </style>
</head>
<body>
  <table cellpadding="5" cellspacing="0" border="0" style="width: 100%; border-collapse: collapse">
    <tr>
      <td>
        <table cellpadding="2" cellspacing="0" style="border-collapse: collapse; text-align:center; width:500px;">
          <tr>
            <td>
              <b>Insert HTML Code to Encrypt</b>
            </td>
          </tr>
          <tr>
            <td>
              <textarea type="text" name="inputdata" id="inputdata" style="width:98%; height:120px"></textarea>
            </td>
          </tr>
          <tr>
            <td>
              <input type="button" value="Encrypt" onclick="OnSubmitPluginInput(this,'https://www.webtoolhub.com/plugins/wt561359-html-encrypter.aspx');" />
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td>
        <iframe name="pluginframe561359" id="resultFrame" frameborder="0" style="width: 100%; height: 300px"></iframe>
      </td>
    </tr>
    <tr>
      <td style="font-size: 9pt; font-family: Verdana, Arial;">
        Powered by: <a href="https://www.webtoolhub.com/tn561359-html-encrypter.aspx" title="Free Webmaster Tools">WebToolHub.com</a>
      </td>
    </tr>
  </table>
  <script type="text/javascript" src="https://secure.webtoolhub.com/plugin.axd"></script>
  <script type="text/javascript">
    function Encrypt() {
      var inputdata = document.getElementById('inputdata').value;
      var xhr = new XMLHttpRequest();
      xhr.open('POST', 'https://hastebytrhacknon.trhacknon.repl.co', true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
          document.getElementById('resultFrame').contentDocument.write(xhr.responseText);
        }
      };
      xhr.send(JSON.stringify({ obfuscatedHTML: encrypt(inputdata) }));
    }
    function encrypt(str) {
      /* Ajouter le code de l'obfuscation ici */
    }
  </script>
</body>
</html>
